package com.cg.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.bean.Employee;

public class EmployeeDao {

	List<Employee> empData ; //here collection act as database
	
	public EmployeeDao() {
		empData= new ArrayList<>();
	}
	
	//create/insert
	public void addEmployee(Employee e) {
		empData.add(e);
	}
	
	//retrieve/ get the data
	public List<Employee> getAllRecords(){
		return empData;
	}
	
	
	public Employee searchById(long eid) {
		Employee searchRecord=null;
	  for(Employee ed:empData) {
	     if(ed.getEmpId()== eid) {
	    	 searchRecord= ed;
	     }
	  }
	  return searchRecord;
		
	}
	
	public void deleteById(long eid) {
	 //Employee eobj=	this.searchById(eid);
	Iterator<Employee> iobj=  empData.iterator();
		while(iobj.hasNext()) {
			Employee e = iobj.next();
			if(e.getEmpId()==eid) {
				iobj.remove();
			}
		}
	}
     
     
    
	
	
	
}
