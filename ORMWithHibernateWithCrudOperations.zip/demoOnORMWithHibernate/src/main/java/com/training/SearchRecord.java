package com.training;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.entity.Book;

/**
 * Hello world!
 *
 */
public class SearchRecord 
{
    public static void main( String[] args )
    {
    	Configuration cfg = new Configuration();
    	cfg.configure();
    	
        SessionFactory sft= cfg.buildSessionFactory();
        
        Session session=sft.openSession();
       Book searchRecord= session.find(Book.class,1);
        
       if(searchRecord!=null) {
    	   System.out.println("Record is Found");
    	   System.out.println(searchRecord);
       }else {
    	   System.out.println("Record Not Found");
       }
           
       
        
        
        
        
        session.close();
    	
    }
}
