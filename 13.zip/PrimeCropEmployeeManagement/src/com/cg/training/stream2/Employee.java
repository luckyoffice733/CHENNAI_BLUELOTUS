package com.cg.training.stream2;

import java.time.LocalDate;

public class Employee {
	String employeeId;
	String employeeName;
	String departmentName;
	LocalDate joiningDate;
	String role;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String employeeId, String employeeName, String departmentName, LocalDate joiningDate, String role) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.departmentName = departmentName;
		this.joiningDate = joiningDate;
		this.role = role;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public LocalDate getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", departmentName="
				+ departmentName + ", joiningDate=" + joiningDate + ", role=" + role + "]";
	}
	
}
