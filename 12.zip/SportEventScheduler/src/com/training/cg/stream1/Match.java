package com.training.cg.stream1;

import java.time.LocalDate;

public class Match {
	String matchCode;
	String matchTitle;
	String coordinator;
	LocalDate matchDate;
	String venue;
	
	
	public Match() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Match(String matchCode, String matchTitle, String coordinator, LocalDate matchDate, String venue) {
		super();
		this.matchCode = matchCode;
		this.matchTitle = matchTitle;
		this.coordinator = coordinator;
		this.matchDate = matchDate;
		this.venue = venue;
	}

	public String getMatchCode() {
		return matchCode;
	}
	public void setMatchCode(String matchCode) {
		this.matchCode = matchCode;
	}
	public String getMatchTitle() {
		return matchTitle;
	}
	public void setMatchTitle(String matchTitle) {
		this.matchTitle = matchTitle;
	}
	public String getCoordinator() {
		return coordinator;
	}
	public void setCoordinator(String coordinator) {
		this.coordinator = coordinator;
	}
	public LocalDate getMatchDate() {
		return matchDate;
	}
	public void setMatchDate(LocalDate matchDate) {
		this.matchDate = matchDate;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	
	//Generate the following
	//constructors
	//Setters and Getters
	//toString
	
	
}