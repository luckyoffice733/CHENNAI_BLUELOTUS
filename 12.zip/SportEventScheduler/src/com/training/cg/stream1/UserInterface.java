package com.training.cg.stream1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class UserInterface {
	public static void main(String[] args) {

		List<Match> matchList = new ArrayList<>();

		MatchUtility mu = new MatchUtility();

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of Matches:");

		int num = sc.nextInt();

		sc.nextLine();

		System.out.println("Enter the Match details:");

		for (int i = 1; i <= num; i++) {

			String details = sc.nextLine();

			String s[] = details.split(":");

			String matchCode = s[0];

			String matchTitle = s[1];

			String coordinator = s[2];

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			LocalDate matchDate = LocalDate.parse(s[3], dtf);

			String venue = s[4];
 
			Match match = new Match(matchCode, matchTitle, coordinator, matchDate, venue);

			matchList.add(match);
 
		}

		System.out.println("Enter the Coordinator:");

		String coordinator = sc.nextLine();

		Stream<Match> st = mu.getMatchesByCoordinator(matchList, coordinator);

		if(st.findFirst().isPresent()) {

			System.out.println("Matches for the given coordinator:");

			st.forEach(e->System.out.println(e.getMatchCode()+"|"+e.getMatchTitle()+"|"+e.getCoordinator()+"|"+e.getMatchDate()+"|"+e.getVenue()));
 
		}else {

			System.out.println("No matches found for the given Coordinator "+coordinator);

		}
 
		Stream<Match> st1=mu.getMatchesInOrderByDate(matchList);

		System.out.println("Matches in ascending order based on match date:");

		st1.forEach(e->System.out.println(e.getMatchCode()+"|"+e.getMatchTitle()+"|"+e.getCoordinator()+"|"+e.getMatchDate()+"|"+e.getVenue()));

		Stream<String> st2=mu.getDistinctMatches(matchList);

		System.out.println("Distinct Matches are:");

		st2.forEach(System.out::println);

	}
 
}

//M4001:Rugby Match:Paul:12-03-2024:Twickenham Stadium

//M4002:Volleyball Match:Anna:05-02-2024:Beach Arena

//M4003:Golf Tournment:Tom:28-08-2024:Augusta National

//M4001:Rugby Match:Paul:13-03-2024:Twickenham Stadium


