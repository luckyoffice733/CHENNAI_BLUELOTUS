package com.cg.training.stream2;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class EmployeeUtility {
	public Stream<Employee> getEmployeesByDepartment(List<Employee> employeeList,String departmentName){

		return null;

	}

	public Stream<Employee> getEmployeesInAscendingOrderByDate(List<Employee> employeeList){

		return null;
	}

	public Stream<String> getUniqueEmployeeRoles(List<Employee> employeeList){

		return null;

	}
}
