package com.training.cg.stream4;

public class TrainingProgram {
	String programName;
	String trainerName;
	String topic;
	int duration;
	public TrainingProgram() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TrainingProgram(String programName, String trainerName, String topic, int duration) {
		super();
		this.programName = programName;
		this.trainerName = trainerName;
		this.topic = topic;
		this.duration = duration;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getTrainerName() {
		return trainerName;
	}
	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	@Override
	public String toString() {
		return "TrainingProgram [programName=" + programName + ", trainerName=" + trainerName + ", topic=" + topic
				+ ", duration=" + duration + "]";
	}
	
}
