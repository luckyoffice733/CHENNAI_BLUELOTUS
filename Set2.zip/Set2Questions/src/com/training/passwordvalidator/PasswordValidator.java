package com.training.passwordvalidator;

import java.util.Scanner;

import com.training.exception.PasswordMisMatchException;

public class PasswordValidator {

	public static boolean validatePassword(String pwd,String cfmpwd)throws PasswordMisMatchException {
		boolean b=false;
		String regex="\\w+[@]\\d+";
		
		/*
		 * if(pwd.matches(regex) && cfmpwd.matches(regex)){
		 * System.out.println("Pattern matched"); return true; }else
		 */
		if(pwd.matches(regex) && cfmpwd.matches(regex) && pwd.equals(cfmpwd)){
			return true;
		}else {
			throw new PasswordMisMatchException("Password entered doesnot match");
		}
		
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the customerName");
		String cname = sc.nextLine();
		System.out.println("Enter the password");
		String pwd = sc.nextLine();
		
		System.out.println("Re-enter the password to confirm");
		String cnfpwd = sc.nextLine();
	     try {
		boolean bt=validatePassword(pwd,cnfpwd);
		if(bt) {
			System.out.println("Registered Successfully");
		}
	     }catch (PasswordMisMatchException pe) {
		    System.out.println(pe.getMessage());
		}
		
	}
}
