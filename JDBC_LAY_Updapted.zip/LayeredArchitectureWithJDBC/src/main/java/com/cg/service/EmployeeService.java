package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDao;

public class EmployeeService {
	
	public EmployeeDao emDao; //has-a relation
	
	public EmployeeService() {
		emDao= new EmployeeDao();
	}
	
	public void addEmployee(Employee eobj) {
		emDao.addEmployee(eobj); //passing data from serivce layer to datalayer
	}
	
	public List<Employee> getAllEmployee(){
		return emDao.getAllRecords();
	}
	
	public Employee searchByEmpid(long eid) {
		return emDao.searchById(eid);//pass to data layer
	}
	
	public void deleteById(long eid) {
		emDao.deleteById(eid);///pass to data layer
	}
	
	public void udpateEmployee(Employee eobj) {
		emDao.updateEmployee(eobj); //passing data from serivce layer to datalayer
	}
	 
}
