package com.training.code;

public class Calculation {

	public int addNumber(int x,int y) {
		return x+y;
	}
	
	
	public int multiply(int x,int y) {
		return x*y;
	}
	
	public int getSum(int x,int y) {
		return x+y;
	}
	
}
