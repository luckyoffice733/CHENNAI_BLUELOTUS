package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeNotFound;
import com.cg.service.EmployeeService;

public class Main {

	public static void main(String[] args) {
		EmployeeService eService = new EmployeeService();

		Scanner sc = new Scanner(System.in);
		char ch = 'y';

		System.out.println("Employee Management System");
		do {

			System.out.println("Menu");
			System.out.println("1.Add Employee");
			System.out.println("4.Delete Employee By empid");
			System.out.println("2.List All Employee Records");
			System.out.println("3.Search An Employee with Empid");
			System.out.println("6.Update An Employee with Empid");
			System.out.println("5.EXIT");

			System.out.println("Enter the choice");
			int choice = sc.nextInt();

			switch (choice) {

			case 1:
				System.out.println("Enter the employeeId");
				long eid = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the employeeName");
				String ename = sc.nextLine();
				System.out.println("Enter the employeeSalary");
				double esal = sc.nextDouble();

				Employee e1 = new Employee(eid, ename, esal);

				eService.addEmployee(e1);// to passing data into service Layer

				break;
			case 2:
				System.out.println("Employee Details are : ");
				List<Employee> ls = eService.getAllEmployee();
				for (Employee de : ls) {
					System.out.println(de);
				}

				break;
			case 3:
				System.out.println("Enter the empid to search ");
				long id = sc.nextLong();
				Employee e = eService.searchByEmpid(id);// passing to service layer
				if (e != null) {
					System.out.println("Employee Record is found based on id");
					System.out.println(e);
				} else {
					System.out.println("REcord not found based on empid...!");
				}

				break;

			case 4:
				System.out.println("Enter the empid to delete ");
				long deid = sc.nextLong();
				try {
				eService.deleteById(deid);
				}catch (EmployeeNotFound ent) {
					// TODO: handle exception
					System.err.println(ent.getMessage());
				}
				break;
				
			case 6:
				System.out.println("Enter the employeeId To Update");
				long eid1 = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the New employee name to update");
				String ename1 = sc.nextLine();
				System.out.println("Enter the New employeeSalary to update");
				double esal1 = sc.nextDouble();

				Employee e2 = new Employee(eid1, ename1, esal1);
                try {
				eService.udpateEmployee(e2);// to passing data into service Layer
                }catch(EmployeeNotFound et) {
                	System.err.println(et.getMessage());
                }
				break;

			case 5:
				System.out.println("Exists From Operation");
				ch = 'Y';

			}

		} while (ch != 'Y');

	}

}
