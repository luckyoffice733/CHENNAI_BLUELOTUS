package com.cg.streams3;

import java.time.LocalDate;

public class ShoeDetails {

	String shoeId;
	String shoeName;
	String brandName;
	LocalDate arrivalDate;
	int size;
	public ShoeDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ShoeDetails(String shoeId, String shoeName, String brandName, LocalDate arrivalDate, int size) {
		super();
		this.shoeId = shoeId;
		this.shoeName = shoeName;
		this.brandName = brandName;
		this.arrivalDate = arrivalDate;
		this.size = size;
	}
	public String getShoeId() {
		return shoeId;
	}
	public void setShoeId(String shoeId) {
		this.shoeId = shoeId;
	}
	public String getShoeName() {
		return shoeName;
	}
	public void setShoeName(String shoeName) {
		this.shoeName = shoeName;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public LocalDate getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(LocalDate arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	@Override
	public String toString() {
		return "ShoeDetails [shoeId=" + shoeId + ", shoeName=" + shoeName + ", brandName=" + brandName
				+ ", arrivalDate=" + arrivalDate + ", size=" + size + "]";
	}
	
	
}
