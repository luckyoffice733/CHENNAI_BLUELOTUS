package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.bean.Employee;
import com.cg.utility.DBUtil;

public class EmployeeDao {

	List<Employee> empData = new ArrayList<>() ; //here collection act as database
	
	public EmployeeDao() {
		
	}
	
	//create/insert
	public void addEmployee(Employee e) {
		Connection con=  DBUtil.getMySqlConnection();
		String query="insert into employee_tab values(?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setLong(1,e.getEmpId());
			pstmt.setString(2,e.getEmpName());
			pstmt.setDouble(3,e.getEmpSal());
			
			int iobj =pstmt.executeUpdate();
			if(iobj >0) {
				System.out.println("Record Inserted....");
			}else {
				System.out.println("Record Not inserted");
			}
			
			pstmt.close();
			DBUtil.closeMySqlConnection(con);
			
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	//retrieve/ get the data
	public List<Employee> getAllRecords(){
		Connection con=  DBUtil.getMySqlConnection();
		String query="select * from employee_tab";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			while(rs.next()) {
				Employee eobj = new Employee(rs.getLong(1),rs.getString(2),rs.getDouble(3));
				empData.add(eobj);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return empData;
	}
	
	
	public Employee searchById(long eid) {
		Employee searchRecord=null;
	  for(Employee ed:empData) {
	     if(ed.getEmpId()== eid) {
	    	 searchRecord= ed;
	     }
	  }
	  return searchRecord;
		
	}
	
	public void deleteById(long eid) {
	 //Employee eobj=	this.searchById(eid);
	Iterator<Employee> iobj=  empData.iterator();
		while(iobj.hasNext()) {
			Employee e = iobj.next();
			if(e.getEmpId()==eid) {
				iobj.remove();
			}
		}
	}
     
     
    
	
	
	
}
