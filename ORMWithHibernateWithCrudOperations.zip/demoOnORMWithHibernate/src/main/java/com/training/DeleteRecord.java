package com.training;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.entity.Book;

/**
 * Hello world!
 *
 */
public class DeleteRecord 
{
    public static void main( String[] args )
    {
       

    	Configuration cfg = new Configuration();
    	cfg.configure();
    	
        SessionFactory sft= cfg.buildSessionFactory();
        
        Session session=sft.openSession();
        
       Transaction tx= session.beginTransaction();
       Book bfound= session.find(Book.class,2);
     if(bfound!=null) {
    	   
    	   session.remove(bfound);
    	 System.out.println("Record is deleted");
     }else {
    	 System.out.println("Record not found ..!");
     }
    
    
        tx.commit();
    
    
     session.close();
    }
}
