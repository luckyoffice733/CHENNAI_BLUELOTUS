package com.cg.exception;

public class EmployeeNotFound extends Exception{

	public EmployeeNotFound(String msg) {
		super(msg);
	}
	
}
