package com.cg.streams3;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class ShoeUtility {

	public Stream<ShoeDetails> fetchShoesByBrand(List<ShoeDetails> shoeList,String brandName){

		return null;

	}

	public Stream<ShoeDetails> fetchShoesInAscendingOrderBySize(List<ShoeDetails> shoeList){

		return null;
	}

	public Stream<String> fetchUniqueShoes(List<ShoeDetails> shoeList){

		return null;

	}

}
