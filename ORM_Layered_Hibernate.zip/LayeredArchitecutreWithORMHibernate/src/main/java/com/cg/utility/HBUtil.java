package com.cg.utility;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HBUtil {
	
	static Session session=null;
	public static Session getMySqlSessionObject() {
		Configuration cfg= new Configuration();
		cfg.configure();
		
		SessionFactory sfty = cfg.buildSessionFactory();
		session=sfty.openSession();
		return session;
		
	}

}
