package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.bean.Employee;
import com.cg.utility.DBUtil;

public class EmployeeDao {

	
	
	public EmployeeDao() {
		
	}
	
	//create/insert
	public void addEmployee(Employee e) {
		Connection con=  DBUtil.getMySqlConnection();
		String query="insert into employee_tab values(?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setLong(1,e.getEmpId());
			pstmt.setString(2,e.getEmpName());
			pstmt.setDouble(3,e.getEmpSal());
			
			int iobj =pstmt.executeUpdate();
			if(iobj >0) {
				System.out.println("Record Inserted....");
			}else {
				System.out.println("Record Not inserted");
			}
			
			pstmt.close();
			DBUtil.closeMySqlConnection(con);
			
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	//retrieve/ get the data
	public List<Employee> getAllRecords(){
		List<Employee> empData = new ArrayList<>() ;
		Connection con=  DBUtil.getMySqlConnection();
		String query="select * from employee_tab";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			while(rs.next()) {
				Employee eobj = new Employee(rs.getLong(1),rs.getString(2),rs.getDouble(3));
				empData.add(eobj);
			}
			
			rs.close();
			DBUtil.closeMySqlConnection(con);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return empData;
	}
	
	
	public Employee searchById(long eid) {
		Employee searchRecord=null;   
		Connection con=  DBUtil.getMySqlConnection();
		String query="select * from employee_tab where empno=?";

		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setLong(1,eid);
			ResultSet rs=pstmt.executeQuery();
		   if(rs.next()) {
			   searchRecord=new Employee(rs.getLong(1),rs.getString(2),rs.getDouble(3));
		   }
			
			DBUtil.closeMySqlConnection(con);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	  return searchRecord;
	}
	
	public void deleteById(long eid) {
		Employee e= searchById(eid);
		Connection con=  DBUtil.getMySqlConnection();
		String query="delete from employee_tab where empno=?";
		if(e!=null) {
			PreparedStatement pstmt;
			try {
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1,e.getEmpId());
				
				pstmt.executeUpdate();
				
				pstmt.close();
		        DBUtil.closeMySqlConnection(con);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}else 
		{
			System.out.println("Recortd Doest Not exist based on id");
		}
		
		
	}
     
     
	public void updateEmployee(Employee e) {
		Employee e1= searchById(e.getEmpId());
		if(e1!=null) {
			Connection con = DBUtil.getMySqlConnection();
			String query="update employee_tab set ename=?,esal=? where empno=?";
			PreparedStatement pstmt;
			try {
				pstmt = con.prepareStatement(query);
				pstmt.setString(1,e.getEmpName());
				pstmt.setDouble(2,e.getEmpSal());
				
				pstmt.setLong(3,e1.getEmpId());
				
				pstmt.executeUpdate();
				pstmt.close();
				
				DBUtil.closeMySqlConnection(con);
				
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			
			
		}else {
			System.out.println("Record Doest Not exist Based on id : "+e.getEmpId());
		}
		
		
	}
	
	
	
}
