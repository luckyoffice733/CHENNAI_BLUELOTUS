package com.training;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.SelectionQuery;

import com.training.entity.Book;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

/**
 * Hello world!
 *
 */
public class JPQLSelectWithWhereUsingPositionalParameter 
{
    public static void main( String[] args )
    {
       Scanner sc= new Scanner(System.in);
       System.out.println("Enter the bookName to search");
       String bn=sc.nextLine();
    	
       Configuration cfg = new Configuration();
   	cfg.configure();
   	
       SessionFactory sft= cfg.buildSessionFactory();
       
       Session session=sft.openSession();
    
     //?labeled
    //?1 ,?2.... positional parameters
    String query="Select b FROM Book b where b.bookName=?1";
    
    SelectionQuery<Book> sqty = session.createSelectionQuery(query,Book.class);
    sqty.setParameter(1,bn);
    
    
    List<Book> al=   sqty.getResultList();
    System.out.println("Book With Where clause:");
    
    al.forEach(System.out::println);
    
 
 
  session.close();
    	
    }
}
