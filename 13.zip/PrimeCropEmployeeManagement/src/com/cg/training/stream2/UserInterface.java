package com.cg.training.stream2;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class UserInterface {

	public static void main(String[] args) {

		List<Employee> employeeList = new ArrayList<>();

		EmployeeUtility eu = new EmployeeUtility();
 
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of Employees");

		int num = sc.nextInt();

		sc.nextLine();

		System.out.println("Enter the Employee details:");

		for (int i = 1; i <= num; i++) {

			String details = sc.nextLine();

			String s[] = details.split(":");

			String employeeId = s[0];

			String employeeName = s[1];

			String departmentName = s[2];

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			LocalDate joiningDate = LocalDate.parse(s[3], dtf);

			String role = s[4];
 
			Employee employee = new Employee(employeeId, employeeName, departmentName, joiningDate, role);

			employeeList.add(employee);

		}

		System.out.println("Enter the Department name:");

		String department = sc.nextLine();

		Stream<Employee> st1 = eu.getEmployeesByDepartment(employeeList, department);

		List<Employee> ls = st1.toList();

		if (ls.isEmpty()) {

			System.out.println("No employees found for the given department:" + department);

		} else {

			System.out.println("Employees for the given department:");

			for (Employee e : ls) {

				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");

				String joiningDate =dtf.format(e.getJoiningDate());

				System.out.println("Employee Name:" + e.getEmployeeName() + "," + "Joining Date:" +joiningDate);

			}

		}
 
		

		Stream<Employee> st2 = eu.getEmployeesInAscendingOrderByDate(employeeList);

		List<Employee>le= st2.toList();

		System.out.println("Employees in ascending order based on joining date:");

		for (Employee e1 : le) {

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			String joiningDate =dtf.format(e1.getJoiningDate());

			System.out.println("Employee Name:" + e1.getEmployeeName()+ ",Joining Date:" + joiningDate + ",Role:" + e1.getRole());

		}

 

		Stream<String> st3=eu.getUniqueEmployeeRoles(employeeList);

		//System.out.println(st3);

		System.out.println("Unique Employee roles are:");

		st3.forEach(System.out::println);

	}

}

//E001:John Doe:Finance:15-03-2020:Manager

//E002:Jane Smith:IT:22-06-2018:Developer

//E003:Mike Johnson:HR:12-11-2019:Recruiter

//E004:John Doe:Finance:16-03-2020:Manager

//E005:Emily Davis:IT:10-01-2021:Analyst

