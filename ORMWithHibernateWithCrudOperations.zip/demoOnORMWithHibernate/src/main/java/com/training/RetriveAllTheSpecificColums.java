package com.training;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.SelectionQuery;

import com.training.entity.Book;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

/**
 * Hello world!
 *
 */
public class RetriveAllTheSpecificColums 
{
    public static void main( String[] args )
    {
       
 
    	Configuration cfg = new Configuration();
    	cfg.configure();
    	
        SessionFactory sft= cfg.buildSessionFactory();
        
        Session session=sft.openSession();
     
    String query="Select b.bookId,b.bookName FROM Book b";
     SelectionQuery<Object[]> sb=  session.createSelectionQuery(query,Object[].class);
     List<Object[]> al=sb.getResultList();
     
     for(Object obj[]:al) {
    	
    	 System.out.println(obj[0]+" "+obj[1]);
     }
    session.close();
    	
    	
    }
}
