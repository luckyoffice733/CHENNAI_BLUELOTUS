package com.training.test;


import static org.junit.jupiter.api.Assertions.assertEquals;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.training.code.Calculation;

public class CalucationTest {
	
	static Calculation cal=null;
	@BeforeAll
	public static void getCalculationObject() {
		cal = new Calculation();
		System.out.println("Before all method");
	}

	@BeforeEach
	public void methodOne() {
		System.out.println("we are in methodOne");
	}
	
	
	@Test
	//@Order(0)
	public void testAddNumber() {
		System.out.println("Test Case add");
		int actualOutput =cal.addNumber(10, 30);
		int expectedOutput = 40;
		
		assertEquals(expectedOutput,actualOutput);
	}
	
	@Test
	//@RepeatedTest(5)
	//@Disabled
	//@Order(1)
	public void testMultiply() {
		System.out.println("Test Case multiply");
		int actualOutput =cal.multiply(10, 2);
		int expectedOutput = 20;
		assertEquals(expectedOutput,actualOutput);
	}
	
	
	@ParameterizedTest
	@ValueSource(ints= {10,50,60,20})
	public void testGetSum(int n) {
		System.out.println("We are in parameterized testCases");
		int actualOutput =cal.getSum(20,30);
		/* int expectedOutput = 50; */
		assertEquals(n,actualOutput);
	}
	
	
	
	@AfterEach
	public void methodTwo() {
		System.out.println("we are in methodTwo");
	}
	
	@AfterAll
	public static void closeCalculationObject() {
		System.out.println("AfterAll method");
		cal = null;
		
	}
	
	
	
	
	
	
	
}
