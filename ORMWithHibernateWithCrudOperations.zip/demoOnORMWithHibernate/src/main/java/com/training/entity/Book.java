package com.training.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Book {

	@Id
	private long bookId;
	
	@Column(name = "bname",length = 20)
	private String bookName;
	
	@Column
	private  double price;
	
	@Column(name = "authName",length = 20)
	private String authorName;
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Book(long bookId, String bookName, double price, String authorName) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.price = price;
		this.authorName = authorName;
	}


	public long getBookId() {
		return bookId;
	}
	public void setBookId(long bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}


	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", price=" + price + ", authorName=" + authorName
				+ "]";
	}
	
	
	
}
