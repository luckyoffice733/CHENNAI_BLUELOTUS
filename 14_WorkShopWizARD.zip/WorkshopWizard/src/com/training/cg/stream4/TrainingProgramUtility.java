package com.training.cg.stream4;

import java.util.List;
import java.util.stream.Stream;

public class TrainingProgramUtility {
	public List<TrainingProgram> retrieveProgramsByTrainer(Stream<TrainingProgram> programStream, String trainerName) {

		return null;

	}
 
	public List<TrainingProgram> retrieveProgramsByTopic(Stream<TrainingProgram> programStream, String topic) {

		return null;

	}
 
	public List<TrainingProgram> retrieveProgramsByDuration(Stream<TrainingProgram> programStream, int duration) {

		return null;

	}


}
