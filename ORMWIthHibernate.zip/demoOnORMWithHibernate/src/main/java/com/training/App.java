package com.training;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.entity.Book;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
    	Configuration cfg = new Configuration();
    	cfg.configure();
    	
        SessionFactory sft= cfg.buildSessionFactory();
        
        Session session=sft.openSession();
        
       Transaction tx= session.beginTransaction();
       
        Book b = new Book(1,"HarryPoter",700,"JKRowling");
        
        session.persist(b);
        
      
        tx.commit();
        
        session.close();
        
        
        
        
        
        
        
    	
    	
    }
}
