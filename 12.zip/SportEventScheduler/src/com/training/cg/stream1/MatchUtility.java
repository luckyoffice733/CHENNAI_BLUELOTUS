package com.training.cg.stream1;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class MatchUtility {
	public Stream<Match> getMatchesByCoordinator(List<Match> matchList, String coordinator) {
		 
		return null;

	}
 
	public Stream<Match> getMatchesInOrderByDate(List<Match> matchList) {

		return null;
	}
 
	public Stream<String> getDistinctMatches(List<Match> matchList) {

		return null;

	}

}
