package com.training;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.SelectionQuery;

import com.training.entity.Book;

/**
 * Hello world!
 *
 */
public class RetriveAllTheRecordsWIthCreateQuery 
{
    public static void main( String[] args )
    {
       
    	Configuration cfg = new Configuration();
    	cfg.configure();
    	
        SessionFactory sft= cfg.buildSessionFactory();
        
        Session session=sft.openSession();
     
    String query="Select b FROM Book b";
     SelectionQuery<Book> sqy=  session.createSelectionQuery(query,Book.class);
     List<Book> al=sqy.getResultList();
     System.out.println("Book Details are :");
     al.forEach(System.out::println);
     
    session.close();
    	
    }
}
