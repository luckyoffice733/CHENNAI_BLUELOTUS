package com.training;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.entity.Book;

/**
 * Hello world!
 *
 */
public class UpdateRecord 
{
    public static void main( String[] args )
    {
    	Configuration cfg = new Configuration();
    	cfg.configure();
    	
        SessionFactory sft= cfg.buildSessionFactory();
        
        Session session=sft.openSession();
        
       Transaction tx= session.beginTransaction();
       Book bfound= session.find(Book.class,1);
     if(bfound!=null) {
    	   bfound.setBookName("C");
    	   bfound.setPrice(459);
    	   bfound.setAuthorName("BalaguruSwamy");
    	   session.merge(bfound);
    	 System.out.println("Record is updated");
     }else {
    	 System.out.println("Record not found ..!");
     }
    
    
        tx.commit();
    
    
     session.close();
    	
    }
}
