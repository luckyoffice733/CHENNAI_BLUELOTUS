package com.training.cg.stream4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {

		TrainingProgramUtility tpu = new TrainingProgramUtility();

		List<TrainingProgram> lst = new ArrayList<>();

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the total number of training programs to add to the list");

		int num = sc.nextInt();

		sc.nextLine();

		System.out.println("Enter the training program details(programName,trainerName,topic,duration)");

		for (int i = 1; i <= num; i++) {

			String details = sc.nextLine();

			String s[] = details.split(",");
 
			String programName = s[0];

			String trainerName = s[1];

			String topic = s[2];

			int duration = Integer.parseInt(s[3]);
 
			TrainingProgram tp = new TrainingProgram(programName, trainerName, topic, duration);

			lst.add(tp);

		}
 
		System.out.println("Enter the trainer name");

		String trainerName = sc.nextLine();

		List<TrainingProgram> lsp = tpu.retrieveProgramsByTrainer(lst.stream(), trainerName);

		if (lsp.isEmpty()) {

			System.out.println("No program found for the given trainer");

		} else {

			for (TrainingProgram l1 : lsp) {

				System.out.println("Training programs conducted by :" + trainerName);

				System.out.println("Program Name:" + l1.getProgramName() + "/" + "Topic:" + l1.getTopic() + "/Duratio:"

						+ l1.getDuration());

			}

		}

		System.out.println("Enter the topic");

		String topic = sc.nextLine();

		List<TrainingProgram> lst1 = tpu.retrieveProgramsByTopic(lst.stream(), topic);

		if (lst1.isEmpty()) {

			System.out.println("No programs found with the given topic");

		} else {

			for (TrainingProgram l2 : lst1) {

				System.out.println("Training programs with topic '" + topic + "':");

				System.out.println("Program Name:" + l2.getProgramName() + "/" + "Trainer Name:" + l2.getTrainerName()

						+ "/Duration:" + l2.getDuration());

			}

		}

		System.out.println("Enter the minimum duration(in hours)");

		int duration = sc.nextInt();

		List<TrainingProgram> lst2=tpu.retrieveProgramsByDuration(lst.stream(), duration);

		if (lst2.isEmpty()) {

			System.out.println("No programs found with duration greater then the given number");

		} else {

			System.out.println("Training programs with duration greater than " + duration + " hours:");

			for (TrainingProgram l3 : lst2) {

				System.out.println("Program Name:" + l3.getProgramName() +"/Trainer Name:" + l3.getTrainerName()+ "/Topic:" + l3.getTopic()

						+ "/Duration:" + l3.getDuration());

			}

		}


	}

}

//JavaScript Essentials,Toby Flenderson,Programming,10

//Effective Negotiation,Phyllis Vance,Management,14

//Data Analysis,Creed Bratton,Data Science,20

//Digital Marketing,Meredith Palmer,Marketing,16

//Cloud Architecture,Darryl Philibin,IT,18

