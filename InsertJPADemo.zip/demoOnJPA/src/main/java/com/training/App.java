package com.training;

import com.training.entity.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       
   EntityManagerFactory emfty=Persistence.createEntityManagerFactory("productUnit");
    EntityManager eManger=emfty.createEntityManager(); //establish the connection 
     EntityTransaction tx=  eManger.getTransaction();
       tx.begin();
      Product p = new Product(1321,"mouse",800);
      
      eManger.persist(p);
     
    
      tx.commit();
      eManger.close();
    	
    }
}
