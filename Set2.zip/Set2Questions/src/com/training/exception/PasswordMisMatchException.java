package com.training.exception;

public class PasswordMisMatchException extends Exception{

	public PasswordMisMatchException(String m) {
		super(m);
	}
}
