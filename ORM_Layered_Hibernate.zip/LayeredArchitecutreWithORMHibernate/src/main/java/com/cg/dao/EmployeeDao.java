package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.SelectionQuery;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeNotFound;
import com.cg.utility.HBUtil;

public class EmployeeDao {

	
	
	public EmployeeDao() {
		
	}
	
	//create/insert
	public void addEmployee(Employee e) {
		Session sion=  HBUtil.getMySqlSessionObject();
		Transaction tx= sion.beginTransaction();
		sion.persist(e);
		tx.commit();
		sion.close();
	}
	
	//retrieve/ get the data
	public List<Employee> getAllRecords(){
		List<Employee> al = new ArrayList<>();
		String query="Select e from Employee e";
		Session sion=  HBUtil.getMySqlSessionObject();
		SelectionQuery<Employee> sqfty=sion.createSelectionQuery(query,Employee.class);
		al=sqfty.getResultList();
		sion.close();
		
		return al;
		
	}
	
	
	public Employee searchById(long eid) {
		Employee searchRecord=null;   
		Session sion=  HBUtil.getMySqlSessionObject();
		searchRecord =sion.find(Employee.class,eid);
	
	  return searchRecord;
	}
	
	public void deleteById(long eid) throws EmployeeNotFound{
		Employee e= searchById(eid);
		
		if(e!=null) {
			Session sion=  HBUtil.getMySqlSessionObject();
			Transaction tx= sion.beginTransaction();
			sion.remove(e);
			tx.commit();
			sion.close();
		}else 
		{
			throw new EmployeeNotFound("Recortd Doest Not exist based on id");
		}
		
		
	}
     
     
	public void updateEmployee(Employee e) throws EmployeeNotFound{
		Employee e1= searchById(e.getEmpId());
		if(e1!=null) {
			
			Session sion=  HBUtil.getMySqlSessionObject();
			Transaction tx= sion.beginTransaction();
			
			e1.setEmpName(e.getEmpName());
			e1.setEmpSal(e.getEmpSal());
			
		   sion.merge(e1);
			
			tx.commit();
			sion.close();
			
			
		}else {
			throw new EmployeeNotFound("Record Doest Not exist Based on id :"+e.getEmpId());
		}
		
		
	}
	
	
	
}
