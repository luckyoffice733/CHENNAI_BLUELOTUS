package com.cg.streams3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class UserInterface {
   
	public static void main(String[] args) {

		List<ShoeDetails> shoeList = new ArrayList<>();

		ShoeUtility su = new ShoeUtility();

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of Shoe Details:");

		int num = sc.nextInt();

		sc.nextLine();

		System.out.println("Enter the Shoe details:");

		for(int i=1;i<=num;i++) {

			String details = sc.nextLine();

			String s[]=details.split(":");

			String shoeId=s[0];

			String shoeName=s[1];

			String brandName=s[2];

			//String arrivalDate = s[3];

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			LocalDate arrivalDate=LocalDate.parse(s[3], dtf);

			int size=Integer.parseInt(s[4]);

			ShoeDetails sd = new ShoeDetails(shoeId, shoeName, brandName, arrivalDate, size);

			shoeList.add(sd);

		}


		System.out.println("Enter the Brand name");

		String brandName1 = sc.nextLine();

		List<ShoeDetails> lst=su.fetchShoesByBrand(shoeList, brandName1).toList();

		if(lst.isEmpty()) {

			System.out.println("No Shoes found for the given Brand "+brandName1);

		}else {

			System.out.println("Shoes for the given brand:");

			for(ShoeDetails lsd:lst) {

				DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");

				String date = dtf1.format(lsd.getArrivalDate());

				System.out.println("ShoeDetails[shoeId:"+lsd.getShoeId()+",shoeName:"+lsd.getShoeName()+",brandName:"+lsd.getBrandName()+",arrivalDate:"+date+",size:"+lsd.getSize()+"]");
 
			}

		}

		System.out.println("Shoes in ascending order based on size:");

		List<ShoeDetails> st1=su.fetchShoesInAscendingOrderBySize(shoeList).toList();

		for(ShoeDetails lsd1:st1) {

			DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");

			String date = dtf1.format(lsd1.getArrivalDate());

			System.out.println("ShoeDetails[shoeId:"+lsd1.getShoeId()+",shoeName:"+lsd1.getShoeName()+",brandName:"+lsd1.getBrandName()+",arrivalDate:"+date+",size:"+lsd1.getSize()+"]");
 
		}

		Stream<String> st2=su.fetchUniqueShoes(shoeList);

		System.out.println("Unique Shoe names are:");

		st2.forEach(System.out::println);

	}

 
}

//S001:Nike Air Max:Nike:15-03-2021:10

//S002:New Balance 574:New Balance:19-05-2018:10

//S003:Nike Pegasus:Nike:11-11-2017:8


